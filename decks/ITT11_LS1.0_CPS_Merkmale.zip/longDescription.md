**Die sechs Merkmale eines CPS** (nach acatech / Industrie 4.0, vereinbar mit KMK-Lernfeld 7):

*   Sensorik: erfasst physikalische Größen

*   Informationsverarbeitung: Software wertet aus und entscheidet

*   Aktorik: wirkt auf einen physikalischen Vorgang ein (im Prototyp z. B. LEDs als Ersatz für Motoren)

*   Kommunikationsfähigkeit: tauscht Daten mit anderen Geräten aus

*   Nichtlokalität: nicht lokal abgeschlossen, nutzt Server, Cloud oder Fernzugriff (dazu gehört die Speicherung auf Servern oder in der Cloud)

*   Mensch-Maschine-Schnittstelle: Menschen beobachten oder bedienen das System

**20 Karten, jede mit einer entscheidenden Unterscheidung:**

*   CPS: Werkstatttor-Prototyp, smartes Thermostat, fahrerloses Transportfahrzeug

*   Kein CPS: Haustür-Kamera (keine Aktorik), Navi-App (berät nur), WLAN-Steckdose (keine Sensorik), Online-Shop (kein physikalischer Teil), Waschmaschine ohne Netz, Roboterzelle und Rollläden ohne Verbindung nach außen

*   Vorher-nachher: Flugzeug mit Datenfunk, Waschanlage mit Feldbus, Ampel mit Verkehrszentrale, Wetterstation mit Ventil, Lampe mit Sensor

*   Begriffe: mechatronisches System, Speicherung, Schutz vor Angriffen, Raspberry Pi, Bimetall-Thermostat

**Automatisierungspyramide (LS1.3):**

*   Die fünf Ebenen: Feldebene, Steuerungsebene, Prozessleitebene, Betriebsleitebene, Unternehmensleitebene
    
*   Typische Geräte/Systeme je Ebene (Sensor/Aktor, SPS, SCADA/HMI, MES, ERP)
    
*   Latenzanforderungen je Ebene (µs/ms bis Stunden/Tage)
    
*   Echtzeitfähigkeit, Determinismus
    
*   IT vs. OT (Information Technology vs. Operational Technology)
    
*   Klassische Pyramide vs. Mesh-/Cloud-Topologie (Industrie 4.0)
    
*   Cloud-Service-Modelle: IaaS, PaaS, SaaS, DBaaS
    

**Vertikale vs. horizontale Kommunikation (LS1.3):**

*   Definition vertikal (zwischen Ebenen) vs. horizontal (innerhalb einer Ebene)
    
*   Beispiele zuordnen können (PROFINET zwischen zwei Robotern → horizontal; SPS → MES via OPC UA → vertikal)
    
*   Feldbusse: PROFINET, Modbus, CANopen, Industrial Ethernet
    
*   Schichten überspringen (Sensor → Cloud direkt) im Industrie-4.0-Ansatz
    

**SCADA – Supervisory Control and Data Acquisition (LS1.3):**

*   Bedeutung der Abkürzung und Verortung auf der Prozessleitebene
    
*   Vier Hauptaufgaben: Datenerfassung, Visualisierung/Überwachung, Alarmierung/Eingriff, Historisierung
    
*   HMI (Human Machine Interface): Aufgabe, Visualisierung, Sollwert-/Rezepturanpassung
    
*   SCADA-Datenbank / Historian – Zeitreihen, Trendanalyse
    
*   Datenschutz: Maschinen-/Auftrags-IDs ja, Personalien nein
    
*   Condition Monitoring / Predictive Maintenance (Pumpenlaufzeit, Ventilbetätigungen)
    
*   Lokales SCADA vs. Remote-SCADA
    
*   RTU (Remote Terminal Unit) und MTU (Master Terminal Unit)
    
*   Anwendungsbeispiele (Lackierstraße, Wassertank-Befüllung, Gewächshaus)
    

**Kommunikationsmodelle (LS1.4):**

*   Request/Response (synchron, Pull) – Beispiel HTTP, Polling als Nachteil
    
*   Subscription/Notify (asynchron, Push, ohne Broker) – ereignisgetrieben
    
*   Publish/Subscribe (asynchron, Push, mit Broker) – m:n-Verteilung
    
*   Lose Kopplung (räumlich, zeitlich, funktional)
    
*   Synchron vs. asynchron einordnen können
    
*   Vorteile/Nachteile pro Modell
    
*   Broker als Single Point of Failure
    
*   OPC UA vereint alle drei Modelle
    
*   Übergeordnete Anforderungen: Echtzeitfähigkeit, Skalierbarkeit, Flexibilität
    
*   Publisher/Subscriber/Broker im Diagramm zuordnen können
    

**MQTT – Message Queuing Telemetry Transport (LS1.5):**

*   Bedeutung der Abkürzung, Transport TCP/IP
    
*   Standard-Ports: 1883 (unverschlüsselt), 8883 (TLS)
    
*   Rollen: Broker, Publisher, Subscriber (ein Client kann beides sein)
    
*   CONNECT-Parameter: ClientID, Username/Passwort, Keepalive, Last Will, Clean Session
    
*   Topic-Aufbau: hierarchisch, Slash-getrennt, case-sensitive, keine Leerzeichen, kein führender Slash
    
*   Wildcards in Subscriptions: + (eine Ebene), # (mehrere Ebenen, nur am Ende)
    
*   Wildcards NICHT beim Publish erlaubt
    
*   Topic-Hierarchien entwerfen (Ort/Etage/Raum/Sensor)
    
*   QoS-Stufen 0 (höchstens einmal), 1 (mindestens einmal), 2 (genau einmal)
    
*   QoS-Handshakes: PUBACK (1), PUBREC/PUBREL/PUBCOMP (2)
    
*   Retain-Flag: letzte Nachricht je Topic für späte Subscriber
    
*   Last Will and Testament (LWT) – wann wird er ausgelöst
    
*   Keepalive und 1,5×-Regel
    
*   Sicherheit: TLS, Username/Passwort, ggf. Client-Zertifikate
    
*   MQTT vs. HTTP (Overhead, Pattern, Einsatzgebiet)
    
*   Tools: MQTT Explorer (Desktop), MQTT Dash (Smartphone)
    
*   IBH Link UA als Gateway OPC UA ⇄ MQTT
    
*   Mosquitto als typischer Broker
    

**OPC UA – Open Platform Communications Unified Architecture (LS2.4):**

*   Norm IEC 62541, Standard-Port 4840, Schema opc.tcp://
    
*   Abgrenzung zu Classic OPC (kein COM/DCOM, plattformunabhängig, internet-/firewall-tauglich, integrierte Sicherheit)
    
*   Vier Kern-Kompetenzen: Plattform-/Internet-Fähigkeit, semantisches Informationsmodell, Service-orientierte Architektur (SOA), vertikale Integration
    
*   Zwei Säulen: Informationsmodellierung und Übertragungsmechanismen
    

**OPC UA Informationsmodell (LS2.4):**

*   Adressraum (Address Space) als typisierter Knotenbaum
    
*   Knotenklassen: Object, Variable, Method, View
    
*   Typ-Knoten: ObjectType, VariableType, ReferenceType, DataType
    
*   Referenzen (HasComponent, HasTypeDefinition, Organizes)
    
*   NodeId-Aufbau: ns=<index>;<idtype>=<id> mit i/s/b/g
    
*   Namespace-Index: ns=0 = OPC-Standardraum, höhere Indizes = Hersteller/Anwendung/Companion
    
*   Companion Specifications (Euromap 77, PLCopen, VDMA, EDDL)
    
*   Variable vs. Methode (Zustand vs. Aktion)
    

**OPC UA Übertragung (LS2.4):**

*   Drei Mechanismen: Request/Response, Subscription/Notify, Pub/Sub
    
*   Subscription mit Monitored Items (data-change, event, aggregate)
    
*   Sampling Interval vs. Publishing Interval
    
*   Encoding: OPC UA Binary über opc.tcp (effizient) vs. XML/JSON über HTTPS/SOAP
    
*   Pub/Sub-Variante mit Broker (MQTT-ähnlich)
    

**OPC UA Sicherheit (LS2.4):**

*   Drei Säulen: Authentifizierung, Integrität (Signatur), Vertraulichkeit (Verschlüsselung)
    
*   Security Modes: None, Sign, SignAndEncrypt
    
*   X.509-Zertifikate
    
*   Secure Channel vs. Session (Leitung vs. Login)
    

**OPC UA Praxis (LS2.4):**

*   UAExpert (Endpunkt verbinden, Adressraum browsen, Data-Access-View, Knotenattribute inspizieren)
    
*   IBH Link UA als Gateway OPC UA ⇄ MQTT (XML-Konfiguration lesen können)
    
*   Aufbau eines minimalen OPC-UA-Servers in Python: Server-Endpoint, Namespace registrieren, Objects-Knoten, add_object/add_folder/add_variable, set_writable, server.start
    
*   OPC UA vs. MQTT – Datenmodell, Sicherheit, typischer Einsatz

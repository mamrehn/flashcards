**Vorbereitung auf die Kurzarbeit LS1.0**, nach der Mebis-Knowledge-Base ITT11 (CleanControl, Solaranlage). Linux steht im eigenen Deck.

**Projekt und Lasten-/Pflichtenheft:**

*   Merkmale eines Projekts nach DIN 69901-5, Projekt oder Routine

*   Lastenheft (Auftraggeber: WAS und WOFÜR) und Pflichtenheft (Auftragnehmer: WIE und WOMIT), Gliederung, Pflichtenheft als Vertragsgrundlage

**Cyber-physische Systeme:**

*   Definition, Abgrenzung zum mechatronischen System

*   Die sieben Merkmale der Knowledge Base: Kommunikationsfähigkeit, Nichtlokalität, Datenverarbeitung, Autonomie, Besonderer Schutz (Security und Safety), Zuverlässigkeit, Mensch-Maschine-Schnittstelle

*   Vor- und Nachteile

**Mechatronische Systeme:** Modell nach VDI 2206 (Grundsystem, Sensorik, Informationsverarbeitung, Aktorik), Stoff-, Energie- und Informationsfluss, Sensor oder Aktor

**IoT und Industrie 4.0:** IoT, IIoT, Industrie 4.0, Smart Factory, die vier Stufen der Industrialisierung

**Python (Kapitel 6.1 bis 6.5):** print und input, Datentypen, Listen und Dictionaries, if/elif, while und for, Funktionen, Fehlermeldungen lesen. Viele Karten zeigen Code: Was gibt er aus, wo liegt der Fehler?

**Quellen:** Mebis-Knowledge-Base ITT11 (Stand 15.10.2026); DIN 69901-5:2009-01 (zitiert nach FernUniversität in Hagen und LMU München); acatech/Forschungsunion (2013): Umsetzungsempfehlungen Industrie 4.0; Industry IoT Consortium: Vocabulary 2.3 (2020).

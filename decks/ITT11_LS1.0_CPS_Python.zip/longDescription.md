**Vorbereitung auf die Kurzarbeit LS1.0** (CleanControl, Solaranlage). Linux steht im eigenen Deck.

**Projekt**

*   Merkmale eines Projekts, Projekt oder Routine

**Lasten- und Pflichtenheft**

*   Lastenheft (Auftraggeber: WAS und WOFÜR) und Pflichtenheft (Auftragnehmer: WIE und WOMIT)

*   Gliederung des Lastenhefts, Pflichtenheft als Vertragsgrundlage

**Cyber-physische Systeme**

*   Definition, Beispiele, eingebettete Systeme

*   Die sieben Merkmale: Kommunikationsfähigkeit, Nichtlokalität, Datenverarbeitung, Autonomie, Besonderer Schutz (Security und Safety), Zuverlässigkeit, Mensch-Maschine-Schnittstelle

*   Vor- und Nachteile

**Mechatronische Systeme**

*   Modell mit Grundsystem, Sensorik, Informationsverarbeitung und Aktorik; Stoff-, Energie- und Informationsfluss, Sensor oder Aktor, Abgrenzung zum CPS

**IoT und Industrie 4.0**

*   IoT, IIoT, Industrie 4.0, Smart Factory, die vier Stufen der Industrialisierung

**Python**

*   print, Kommentare, Variablen und Datentypen, if/elif, and/or/not, while, for-Schleife (foreach), Funktionen mit Parametern und return. Viele Karten zeigen Code: Was gibt er aus?

*   Nicht enthalten: input(), Zeichenketten durchsuchen, Listen und Dictionaries, Indizes, main(), Fehlermeldungen lesen

**Python im Vergleich zu C#**

*   Kein Semikolon, Einrückung statt geschweifter Klammern, kein Typ vor Variablen, and/or/not, True/False, Kommentare mit #, foreach als for … in, def, Namen mit Unterstrich

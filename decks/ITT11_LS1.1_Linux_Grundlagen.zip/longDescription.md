**Linux-Kommandozeile (LS1.1):**

*   Navigation: ls, cd, pwd

*   Dateiverwaltung: mkdir, cp, mv (auch Umbenennen), rm, cat

*   Typische Verwechslungen mit Windows (del, md, type, cd ohne Ziel), dazu rmdir und touch

**Vorbereitung auf die Kurzarbeit LS1.0** nach der Mebis-Knowledge-Base ITT11 (CleanControl, Solaranlage). Die Links führen zum passenden Kapitel. Linux steht im eigenen Deck.

**Projekt** · Quelle: DIN 69901-5, zitiert nach [FernUniversität in Hagen](https://fernuni-hagen.de/wirtschaftswissenschaft/studium/download/leseproben/lp_31811.pdf)

*   Merkmale eines Projekts, Projekt oder Routine

**Lasten- und Pflichtenheft** · Nachlesen: [1. Lastenheft CleanControl](https://lernplattform.bycs.de/mod/book/view.php?id=102326989&chapterid=2323363), [2. Pflichtenheft CleanControl](https://lernplattform.bycs.de/mod/book/view.php?id=102326989&chapterid=2323366), [3. Pflichtenheft Solaranlage](https://lernplattform.bycs.de/mod/book/view.php?id=102326989&chapterid=2324323)

*   Lastenheft (Auftraggeber: WAS und WOFÜR) und Pflichtenheft (Auftragnehmer: WIE und WOMIT); Definitionen nach DIN 69901-5, zitiert nach [LMU München](https://www.sosy-lab.org/Teaching/2016-WS-JurPM/Lasten-%20und%20Pflichtenhefte%20%28Ausarbeitung%29.pdf)

*   Gliederung des Lastenhefts, Pflichtenheft als Vertragsgrundlage

**Cyber-physische Systeme** · Nachlesen: [4. Definition und Merkmale](https://lernplattform.bycs.de/mod/book/view.php?id=102326989&chapterid=2338454)

*   Definition, Beispiele, eingebettete Systeme

*   Die sieben Merkmale: Kommunikationsfähigkeit, Nichtlokalität, Datenverarbeitung, Autonomie, Besonderer Schutz (Security und Safety), Zuverlässigkeit, Mensch-Maschine-Schnittstelle

*   Vor- und Nachteile

**Mechatronische Systeme** · Nachlesen: [5. Mechatronische Systeme](https://lernplattform.bycs.de/mod/book/view.php?id=102326989&chapterid=2323384)

*   Modell nach VDI 2206 (Grundsystem, Sensorik, Informationsverarbeitung, Aktorik), Stoff-, Energie- und Informationsfluss, Sensor oder Aktor, Abgrenzung zum CPS

**IoT und Industrie 4.0** · Quellen: [acatech 2013](https://www.acatech.de/wp-content/uploads/2018/03/Abschlussbericht_Industrie4.0_barrierefrei.pdf), [Industry IoT Consortium](https://www.iiconsortium.org/pdf/Vocabulary-Report-2.3.pdf)

*   IoT, IIoT, Industrie 4.0, Smart Factory, die vier Stufen der Industrialisierung

**Python** · Nachlesen: [6. Python Übersicht](https://lernplattform.bycs.de/mod/book/view.php?id=102326989&chapterid=2327605), [6.1 Ausgabe, Variablen, Eingabe](https://lernplattform.bycs.de/mod/book/view.php?id=102326989&chapterid=2327608), [6.3 Verzweigungen und Schleifen](https://lernplattform.bycs.de/mod/book/view.php?id=102326989&chapterid=2327632), [6.4 Funktionen](https://lernplattform.bycs.de/mod/book/view.php?id=102326989&chapterid=2327638)

*   print, Kommentare, Variablen und Datentypen, if/elif, and/or/not, while, for-Schleife (foreach), Funktionen mit Parametern und return. Viele Karten zeigen Code: Was gibt er aus?

*   Nicht enthalten: input(), Zeichenketten durchsuchen, Listen und Dictionaries, Indizes, main(), Fehlermeldungen lesen

**Python im Vergleich zu C#**

*   Kein Semikolon, Einrückung statt geschweifter Klammern, kein Typ vor Variablen, and/or/not, True/False, Kommentare mit #, foreach als for … in, def, Namen mit Unterstrich

**Die sieben Merkmale eines CPS** · Nachlesen: [4. Cyber-physische Systeme: Definition und Merkmale](https://lernplattform.bycs.de/mod/book/view.php?id=102326989&chapterid=2338454)

*   Kommunikationsfähigkeit: vernetzte Teilsysteme mit Sensoren und Aktoren, Interoperabilität (OPC UA, MQTT)

*   Nichtlokalität: Teilsysteme an verschiedenen Standorten, Middleware zu Servern und Cloud

*   Datenverarbeitung: lokal in den Komponenten und zentral auf Servern oder in der Cloud

*   Autonomie: entscheidet in festen Grenzen selbst, passt sich an

*   Besonderer Schutz: Security (Systemhärtung) und Safety (z. B. Not-Aus)

*   Zuverlässigkeit: Fehlertoleranz, Verfügbarkeit (z. B. Zwischenspeichern bei Netzausfall)

*   Mensch-Maschine-Schnittstelle: überwachen und eingreifen (Dashboard, Touchpanel, App)

**18 Karten, jede mit einer entscheidenden Unterscheidung:**

*   Merkmal erkennen: Security, Safety und Zuverlässigkeit trennen; Interoperabilität oder Middleware; Autonomie oder Datenverarbeitung

*   Beispiele prüfen: CleanControl, smartes Thermostat, Transportroboter

*   Was kommt hinzu? Ampel, Störungen auf dem Handy, Rechenzentrum

**Abgrenzung zum mechatronischen System** · Nachlesen: [5. Mechatronische Systeme](https://lernplattform.bycs.de/mod/book/view.php?id=102326989&chapterid=2323384)

*   Neu ist vor allem das offene, globale Netz; eine Roboterzelle ohne Verbindung nach außen ist kein CPS

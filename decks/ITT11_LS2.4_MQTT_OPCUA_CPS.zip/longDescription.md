**Von OPC Classic zu OPC UA:**

*   Problemstellung der 1990er: herstellerspezifische Treiber zwischen Steuerung und SCADA

*   Schwächen von OPC Classic: COM/DCOM (Windows-Bindung), kaum internetfähig

*   OPC UA ab 2008: plattformunabhängig, TCP-Port 4840, integrierte Verschlüsselung

**Kern-Kompetenzen von OPC UA:**

*   Cross Platform & Internet Ready

*   Komplexes, semantisches Informationsmodell

*   Service Oriented Architecture (SOA)

*   Vertikale Kommunikation: Shopfloor (OT) → Operations Level (IT) → Enterprise Level (Cloud)

**Informationsmodell:**

*   Adressraum als Full-Mesh-Network aus Nodes (Attribute, Methoden, Ereignisse)

*   NodeID (z. B. ns=2;i=3): Namespace-Index, Identifier-Typ, Identifier-Wert

*   Companion Specifications (z. B. Euromap77) mit NodeSet-XML

**Übertragungsmechanismen:**

*   Request and Response

*   Subscription and Notify (Secure Channel, Session, Monitored Items, individuelle Abtastintervalle)

*   Publish and Subscribe (Broker über MQTT/AMQP oder brokerlos per UDP-Multicast)

**Sicherheit:**

*   Zertifikatsbasierte Authentifizierung, Signierung von Nachrichten, Verschlüsselung (SSL/TLS/AES)

**OPC UA vs. MQTT:**

*   OPC UA standardisiert Transport UND Datenmodell – MQTT nur den Transport

*   Semantische Interoperabilität durch Companion Specifications

**NoSQL-Grundlagen (LS1.6):**

*   „Not only SQL" – Zugriff über APIs und Datenverwaltungsschicht

*   Konsistenzmodelle BASE (Basic Availability, Soft-state, Eventual Consistency) vs. ACID

*   Die vier NoSQL-Datenbankmodelle: dokumentenorientiert (MongoDB), spaltenorientiert (Cassandra), Graphdatenbank (Neo4j), Key-Value (Redis)

*   Abgrenzung zu relationalen Datenbanken: Schema-Flexibilität, Beziehungen, Redundanzen, Skalierung, Abfragesprache

*   Anwendungsfälle: Wann NoSQL, wann relational? (Banktransaktionen vs. Chatnachrichten/Statusmeldungen)

**Skalierung und Cloud (LS1.7):**

*   Vertikale Skalierung (Scale-up) vs. horizontale Skalierung (Scale-out)

*   Database as a Service (DBaaS) – Leistungen des Providers

*   Cluster, Replica Sets (Primary/Secondary, Wahl bei Ausfall), Sharding (bereichsbasiert, Geo, gehasht), Query Router

*   CAP-Theorem: Konsistenz, Verfügbarkeit, Ausfalltoleranz – nur 2 von 3

**Middleware (LS2.6):**

*   Definition: Vermittlung zwischen heterogenen Systemen und Datenquellen

*   OPC Router (Inray): (Plugin-Bereich, Verbindungen, Transferobjekte und) Trigger

*   Vor- und Nachteile von Middleware (fertige Plugins vs. Lizenzkosten/Herstellerabhängigkeit)

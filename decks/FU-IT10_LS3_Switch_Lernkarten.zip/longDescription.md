**Ethernet Frame:**

*   Aufbau eines Ethernet II Frames (5 Felder nach SFD)
    
*   Destination MAC, Source MAC, EtherType, Payload, CRC/FCS – Funktionen und Größen in Bytes
    
*   Minimale und maximale Framegröße (64–1518 Bytes)
    
*   Datenübertragungseffizienz eines Frames (variable Payload Größe vs. Overhead durch Header)
    

**ARP (Address Resolution Protocol):**

*   Funktion erklären: IP-Adresse → MAC-Adresse auflösen
    
*   ARP-Request (Broadcast) und ARP-Reply (Unicast)
    
*   ARP-Cache / ARP-Tabelle auf Endgeräten
    
*   Konsolenbefehle: arp -a, arp -d
    
*   Zusammenspiel der drei Zuordnungstabellen: DNS → ARP → SAT
    

**Switching-Verfahren:**

*   Cut-Through
    
*   Store-and-Forward
    
*   Adaptive Cut-Through
    

**Source Address Table (SAT):**

*   SAT / MAC-Adresstabelle / Forwarding Table (nur unterschiedliche Namen, selbes Konzept)
    
*   Funktion: Zuordnung MAC-Adresse → Port
    
*   Lernprozess aus Quell-MAC eingehender Frames
    
*   Flooding bei unbekannter Ziel-MAC
    
*   Aging-Mechanismus der SAT Einträge
    
*   Flooding vs. Broadcast
    
*   Unicast vs. Broadcast
    

**Switch-Leistungsmerkmale:**

*   Switching Capacity berechnen
    
*   Non-blocking vs. Blocking Switch
    
*   Vollduplex vs. Halbduplex für Berechnung
    

**Switch-Typen und Funktionen:**

*   Managed vs. Unmanaged Switch (Einsatzszenarien)
    
*   Power over Ethernet (PoE)
    
*   Switch vs. Hub (SAT vs. kein lernen, Prüfsumme checken)
**REST-Grundlagen (LS2.8):**

*   REST = Representational State Transfer – ein Paradigma für die Softwarearchitektur verteilter Systeme (Abstraktion des World Wide Web)

*   Ressource über Webserver verfügbar und eindeutig über eine URL identifiziert; Client und Server lose gekoppelt

*   Zustandslosigkeit (jede Anfrage in sich geschlossen) und ihr Nutzen für die Skalierung

*   Die 6 REST-Design-Prinzipien: Client-Server, Zustandslosigkeit, Caching, Einheitliche Schnittstelle, Mehrschichtige Systemarchitektur, Code on Demand (optional)

**CRUD und HTTP-Methoden (LS2.8):**

*   CRUD ↔ HTTP-Methoden: Create→POST, Read→GET, Update→PUT, Delete→DELETE (Webshop-Beispiel)

*   Ablauf eines POST (Daten im Body, Token/API-Key im Header, Validierung, 201 Created)

*   Warum GET und DELETE ohne Body auskommen (Parameter statt Nutzdaten)

**HTTP-Request und -Response (LS2.8):**

*   Request: Request Line (Methode, URL, Protokoll), Header (Metainfos, Token, Cookies, API-Key), Leerzeile, Body (optional)

*   Response: Status Line (Protokoll, Statuscode, Beschreibung), Header, Leerzeile, Body (JSON/XML/HTML)

**URL und Endpunkte (LS2.8):**

*   Aufbau einer URL: Protokoll, Host, Port, Application Context, Version, Resource, Parameter

*   Endpunkt, Platzhalter ({} oder :) und Query-Parameter (? und &) zum Filtern/Sortieren

**HTTP-Statuscodes (LS2.8):**

*   Klassen 1xx–5xx, Schwerpunkt 2xx (Erfolg), 4xx (Clientfehler), 5xx (Serverfehler)

*   Konkrete Codes: 200 OK, 201 Created, 204 No Content, 404 Not Found, 500 Internal Server Error

**Vor- und Nachteile / API-Vergleich (LS2.8):**

*   Vorteile (plattform-/sprachunabhängig, skalierbar, zustandslos) und Nachteile (Datenmodellierung, uneinheitliche Fehlerbehandlung, Traffic)

*   Abgrenzung REST ↔ SOAP (XML only, ACID, Sicherheit) sowie RPC und GraphQL

**Flask und Raspberry Pi (LS2.8):**

*   Flask als minimales Python-Webframework (Abgrenzung zu Django/Web2py), Installation mit pip

*   App-Instanz (Flask(__name__)), Routing mit @app.route(), Pfad-Platzhalter, app.run(host/port)

*   request.get_json() und request.args.get() lesen, jsonify(data) mit Statuscode zurückgeben

*   Templates (render_template, {{…}}-Platzhalter) und die GPIO-Routen der Werkstatttor-Überwachung (Autohaus Nettmann)

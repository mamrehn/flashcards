**CPS-Grundlagen:**

*   Definition Cyber-physisches System (Mechanik + Software + IT, vernetzt)

*   Komponenten: Sensoren, Aktoren, eingebettete Systeme

*   Bidirektionaler Datenaustausch zwischen physischer und digitaler Welt (geschlossene Regelschleife)

*   Abgrenzung Embedded System vs. CPS (Vernetzung, Autonomie, dynamische Anpassung)

*   Vorteile (Rekonfigurierbarkeit, Selbstoptimierung, Predictive Maintenance) und Herausforderungen (Cyber-Security, Emergent Behavior, Single Point of Failure)

*   Safety vs. Security

**IoT und Industrie 4.0:**

*   Internet of Things (IoT) vs. Industrial IoT (IIoT)

*   Industrie 4.0 als vierte industrielle Revolution

*   Einsatzbereiche: Logistik, Produktion, Medizintechnik, Smart Grid

*   Edge / Fog / Cloud Computing (OPTIONAL)

*   Digital Twin und horizontale/vertikale Integration

**CPS-Modellierung:**

*   Flussarten: Stofffluss, Informationsfluss, Energiefluss

**Linux-Grundlagen:**

*   Navigation und Dateiverwaltung: ls, cd, pwd, mkdir, cp, mv, rm, cat

**Python-Grundlagen:**

*   Ausgabe mit print(), Kommentare, Datentypen (int, float, str, bool), type()

*   Datenstrukturen: Liste, Tupel, Set, Dictionary (Syntax und Eigenschaften)

*   Listen-Methoden: append(), insert(), remove()

*   Funktionen (def) und Schleifen (for, while, List Comprehensions)

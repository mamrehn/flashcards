*   Netzwerkschnittstellen
    
*   LAN Geschwindigkeiten
    
*   Vollduplex und halbduplex
    
*   Netzwerktypen
    
*   Aufbau und Funktion einer MAC-Adresse
    
*   Aufbau und Funktion einer IPv4-Adresse
    
*   Aufbau einer IPv6-Adresse
    
*   Grund für die Weiterentwicklung des IP Protokolls auf IPv6
    
*   IPv4 Subnetzmasken und deren Verwendung für logische Sub-Netze
    
*   Konsolenbefehl(e) um die eigene IP-Adresse und MAC-Adresse herauszufinden
    
*   Netzwerkklassen
    
*   Standardnetzwerkmasken
    
*   Private IPv4-Adressbereiche und deren Funktion
    
*   Netzteil und Hostteil einer IPv4-Adresse
    
*   Funktion eines Standardgateways
    
*   Funktion eines DNS Servers / Protokolls
    
*   Funktion eines DHCP Servers / Protokolls
    
*   VMs: Nutzen und Nachteile von Virtualisierung
    
*   VMs: Übersicht über Ressourcenverteilung und Anforderungen von Windows
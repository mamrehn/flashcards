**Frequenzbänder und Kanäle:**

*   2,4-GHz- vs. 5-GHz-Band (Vor- und Nachteile)
    
*   13 Kanäle im 2,4-GHz-Band in Deutschland
    
*   Nicht überlappende Kanäle (1, 6, 11) und (1, 5, 9, 13)
    
*   Kanalbandbreite und Abstand der Kanäle
    

**Sichere Datenübertragung:**

*   Authentifizierung und Verschlüsselung (Details siehe unten)
    
*   VLAN-Trennung von Kunden- und Mitarbeiter-WLAN
    
*   Hidden SSID als unwirksame Sicherheitsmaßnahme
    
*   Sendeleistung – Begrenzung auf das nötige Minimum
    

**WLAN-Sicherheitsstandards:**

*   WEP – Schwächen, gilt als unsicher
    
*   Verbesserungen von WPA3 gegenüber WPA2
    

**Authentifizierung im WLAN:**

*   WPA2-Personal (PSK) – typischer Anwendungsfall
    
*   WPA2-Enterprise mit RADIUS-Server
    
*   Captive Portal für Kunden-/Gast-WLAN
    
*   Offenes WLAN
    
*   WPS (Wi-Fi Protected Setup) – Risiken, im Unternehmen deaktivieren
    
*   MAC-Adressfilterung als unwirksame Schutzmaßnahme
    

**Schutzbedarf (BSI):**

*   Drei Schutzbedarfskategorien (normal, hoch, sehr hoch)
    
*   Faktoren und Beispiele für die Einstufung
    

**Risiken und Schutzmaßnahmen:**

*   Typische WLAN-Sicherheitsrisiken im Unternehmen (z. B. öffentlich ausgehängtes Passwort)
    
*   Bestandteile eines sicheren Kunden-WLAN-Konzepts
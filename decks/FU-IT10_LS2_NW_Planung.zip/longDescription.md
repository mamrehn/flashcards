**Logischer Netzwerkplan:**

*   Aufbau und Bestandteile eines logischen Netzwerkplans
    
*   Standardisierte Symbole und Legenden
    
*   Netzwerkkonfigurationstabelle (Hostname, IP, Subnetzmaske, Gateway, DNS)
    
*   IP-Adressierungsschema und -strategie
    

**Verkabelungsplan und Gebäudeplan:**

*   Aufbau eines Verkabelungsplans (Patchpanel, Port, Kabelkanal, Raum, Dose)
    
*   Notation im Verkabelungsplan (Wege)
    
*   Gebäudeplan mit Dosenstandorten und Kabelkanälen, Kabellängen und -anzahl
    
*   Revisionsvermerk im Plan
    

**Netzwerktopologien:**

*   Stern-, Bus-, Ring-, Mesh- und Baumtopologie
    
*   Vor- und Nachteile der verschiedenen Topologien
    
*   Begründete Auswahl einer Topologie je Kunde
    

**Strukturierte Verkabelung:**

*   Begriff und Vorteile der strukturierten Verkabelung
    
*   Primär-, Sekundär- und Tertiärverkabelung
    
*   Unterschied Verlegekabel/Installationskabel vs. Patchkabel
    
*   Passive vs. aktive Netzwerkkomponenten
    

**Kabel und Schirmung:**

*   Kabelkategorien (Cat5e, Cat6, Cat6a, Cat7, Cat8) und deren Übertragungsgeschwindigkeiten und Maximallängen
    
*   Schirmungsarten (wie U/UTP, F/UTP, SF/UTP, S/FTP) und deren Bedeutung
    

**Netzwerkschrank:**

*   Komponenten im Netzwerkschrank (Patchpanel, Switch, Router)
    
*   Zusammenspiel Patchpanel und Switch
    
*   Grob: Funktion und Aufbau eines Patchpanels / Doppeldose
    

**Projektdokumentation:**

*   Deckblatt, Anschreiben, Projektbeschreibung
    
*   Stückliste mit passiven und aktiven Komponenten
    
*   Legende und Beschriftung in allen Plänen